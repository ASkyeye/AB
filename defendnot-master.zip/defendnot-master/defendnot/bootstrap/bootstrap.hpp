#pragma once

namespace defendnot {
    void startup();
}
